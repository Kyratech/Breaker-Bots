uint8_t recentChanges(FATFS *FatFs, FIL *file, char *filename, uint8_t linecount);
