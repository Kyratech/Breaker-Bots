void ml_printf(char *str, ...);
